<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Master_kontrak_kerja extends CI_Controller {

	// Load database
	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->helper('url');
		$this->load->model('admins/master_kontrak_model');
	}
	
	// Main Kontrak Kerja
	public function index() {
		if ($this->tank_auth->is_logged_in()) {	

			$mkk  	= $this->mMKontrak->listMKontrak();
			
			$data = array(	'judul_lengkap'	=> $this->config->item('nama_aplikasi_full'),
							'judul_pendek'	=> $this->config->item('nama_aplikasi_pendek'),
							'instansi'		=> $this->config->item('nama_instansi'),
							'credit'		=> $this->config->item('credit_aplikasi'),
							'mkk'			=> $mkk,
							'isi'			=> 'admins/master-kontrak-kerja/list');
			$this->load->view('admins/layout/wrapper',$data);
		}else{
			redirect('auth/login');
		}
	}

	// Read Kontrak Kerja
	public function detail($id_master_kk) {
		if ($this->acl->has_permission('detail-kontrak-kerja')) {

			$mkk 	= $this->mMKontrak->detailMKontrak($id_master_kk);                                           		
			
			$data  = array(		'judul_lengkap'	=> $this->config->item('nama_aplikasi_full'),
								'judul_pendek'	=> $this->config->item('nama_aplikasi_pendek'),
								'instansi'		=> $this->config->item('nama_instansi'),
								'credit'		=> $this->config->item('credit_aplikasi'),
								'mkk'			=> $mkk,
								'isi'			=> 'admins/master-kontrak-kerja/detail');
			$this->load->view('admins/layout/wrapper', $data);
		}else{
			redirect('auth/noaccess');
		}	
	}

	// Create Kontrak Kerja
	public function create() {
		if ($this->acl->has_permission('add-kontrak-kerja')) {

			$kd['nr_k'] = $this->mMKontrak->get_nr_k();
			$mc 		= $this->mMClients->listMClients();
			$pa 		= $this->mMPa->listMPa();	
			$v = $this->form_validation;
			$v->set_rules('no_kontrak','No Kontrak','required');
		
				if($v->run()) {
					
					$config['upload_path'] 		= './upload/klien/file';
					$config['allowed_types'] 	= 'gif|jpg|png|pdf|rar|zip';
					$config['max_size']			= '20000'; // KB			
					$this->load->library('upload', $config);
					if($this->upload->do_upload('file')) {
						
					$data = array(	'judul_lengkap'	=> $this->config->item('nama_aplikasi_full'),
									'judul_pendek'	=> $this->config->item('nama_aplikasi_pendek'),
									'instansi'		=> $this->config->item('nama_instansi'),
									'credit'		=> $this->config->item('credit_aplikasi'),
									'error'			=> $this->upload->display_errors(),
									'kd'			=> $kd,
									'mc'			=> $mc,
									'pa'			=> $pa,
									'isi'			=> 'admins/master-kontrak-kerja/create');
					$this->load->view('admins/layout/wrapper',$data);
					}else{
						$upload_data				= array('uploads' =>$this->upload->data());
						$config['source_file'] 	= './upload/klien/file/'.$upload_data['uploads']['file_name']; 

						$i = $this->input;
						$data = array(	'id_master_client'	=> $i->post('id_master_client'),
										'no_pa'				=> $i->post('no_pa'),
										'nr_k'				=> $kd['nr_k'],
										'no_kontrak'		=> $i->post('no_kontrak'),
										'probs'				=> $i->post('probs'),
										'tgl_kontrak'		=> $i->post('tgl_kontrak'),
										'start'				=> $i->post('start'),
										'due'				=> $i->post('due'),
										'stts_kontrak'		=> $i->post('stts_kontrak'),
										'file'				=> $upload_data['uploads']['file_name'],
										'date'				=> $i->post('date')
									);

						$this->mMKontrak->createMKontrak($data);
						$this->session->set_flashdata('sukses','Success');
						redirect(base_url('admins/master_kontrak_kerja/'));
					}
				}
				// Default page
				$data = array(	'judul_lengkap'	=> $this->config->item('nama_aplikasi_full'),
								'judul_pendek'	=> $this->config->item('nama_aplikasi_pendek'),
								'instansi'		=> $this->config->item('nama_instansi'),
								'credit'		=> $this->config->item('credit_aplikasi'),
								'kd'			=> $kd,
								'mc'			=> $mc,
								'pa'			=> $pa,
								'isi'			=> 'admins/master-kontrak-kerja/create');
				$this->load->view('admins/layout/wrapper',$data);
		}else{
			redirect('auth/noaccess');
		}
	}

	// Edit Client
	public function edit($id_master_kk) {
		if ($this->acl->has_permission('edit-kontrak-kerja')) {
			$mkk	   	= $this->mMKontrak->detailMKontrak($id_master_kk);
			$mc  	   	= $this->mMClients->listMClients();
			$pa 		= $this->mMPa->listMPa();
			$kd['nrk'] 	= $this->mMClients->get_nrk();		

			// Validation
			$v = $this->form_validation;
			$v->set_rules('no_kontrak','No Kontrak','required');
				//Funtion Baca Data
				if($v->run()) {
					if(!empty($_FILES['image']['name'])) {
					$config['upload_path'] 		= './upload/klien/file';
					$config['allowed_types'] 	= 'gif|jpg|png|svg|pdf|rar|zip';
					$config['max_size']			= '20000'; // KB			
					$this->load->library('upload', $config);
					if($this->upload->do_upload('file')) {
				
					$data = array(	'judul_lengkap'	=> $this->config->item('nama_aplikasi_full'),
									'judul_pendek'	=> $this->config->item('nama_aplikasi_pendek'),
									'instansi'		=> $this->config->item('nama_instansi'),
									'credit'		=> $this->config->item('credit_aplikasi'),
									'mkk'			=> $mkk,
									'kd'			=> $kd,
									'mc'			=> $mc,
									'pa'			=> $pa,
									'error'			=> $this->upload->display_errors(),
									'isi'			=> 'admins/master-kontrak-kerja/edit');
					$this->load->view('admins/layout/wrapper', $data);
					}else{
						$upload_data			= array('uploads' =>$this->upload->data());
						$config['source_file'] 	= './upload/klien/file/'.$upload_data['uploads']['file_name']; 
						
					$i = $this->input;

					unlink('./upload/klien/file/'.$mkk['file']);
					unset($kd['nr_k']);

					$data = array(		'id_master_kk'		=> $mkk['id_master_kk'],
										'id_master_client'	=> $i->post('id_master_client'),
										'no_kontrak'		=> $i->post('no_kontrak'),
										'no_pa'				=> $i->post('no_pa'),
										'nr_k'				=> $kd['nr_k'],
										'probs'				=> $i->post('probs'),
										'tgl_kontrak'		=> $i->post('tgl_kontrak'),
										'start'				=> $i->post('start'),
										'due'				=> $i->post('due'),
										'stts_kontrak'		=> $i->post('stts_kontrak'),
										'file'				=> $upload_data['uploads']['file_name'],
										'date'				=> $i->post('date'));
					$this->mMKontrak->editMKontrak($data);
					$this->session->set_flashdata('sukses','Success');
					redirect(base_url('admins/master_kontrak_kerja'));
					}}else{
					//Funtion Insert data dan Redirect ke List
					$i = $this->input;

					$data = array(		'id_master_kk'		=> $mkk['id_master_kk'],
										'id_master_client'	=> $i->post('id_master_client'),
										'no_kontrak'		=> $i->post('no_kontrak'),
										'no_pa'				=> $i->post('no_pa'),
										'probs'				=> $i->post('probs'),
										'tgl_kontrak'		=> $i->post('tgl_kontrak'),
										'start'				=> $i->post('start'),
										'due'				=> $i->post('due'),
										'stts_kontrak'		=> $i->post('stts_kontrak'),
										'date'				=> $i->post('date'),
									);
					$this->mMKontrak->editMKontrak($data);
					$this->session->set_flashdata('sukses','Success');
					redirect(base_url('admins/master_kontrak_kerja'));			
					}
				}

				$data = array(	'judul_lengkap'	=> $this->config->item('nama_aplikasi_full'),
								'judul_pendek'	=> $this->config->item('nama_aplikasi_pendek'),
								'instansi'		=> $this->config->item('nama_instansi'),
								'credit'		=> $this->config->item('credit_aplikasi'),
								'mkk'			=> $mkk,
								'kd'			=> $kd,
								'mc'			=> $mc,
								'pa'			=> $pa,
								'isi'			=> 'admins/master-kontrak-kerja/edit');
				$this->load->view('admins/layout/wrapper', $data);
		}else{
			redirect('auth/noaccess');
		}
	}	

	// Delete Client
	public function delete($id_master_kk) {
		if ($this->acl->has_permission('delete-kontrak-kerja')) {	
			$data = array('id_master_kk' => $id_master_kk);
			$this->mMKontrak->deleteMKontrak($data);		
			$this->session->set_flashdata('sukses','Success');
			redirect(base_url('admins/master_kontrak_kerja'));
		}else{
			redirect('auth/noaccess');
		}
	}		
}