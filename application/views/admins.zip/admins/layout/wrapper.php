<?php
require_once('header.php');
require_once('main.php');
require_once('footer.php');